#!/user/bin/env python
#_*_ coding:utf-8 _*_
import sys
#sys.path.append('F:\hyj\pytho\interfance\util')
#sys.path.append('F:\hyj\pytho\interfance\data')
sys.path.insert(0,'F:\hyj\pytho\interfance')
#sys.path.insert(0,'F:\hyj\pytho\interfance\data')
print sys.path